jQuery(function ($) {
    $('body').on('click', '#place_order', function (e) {

        if ($('#payment_method_ecentric').is(':checked')) {
            //console.log('The ecentric payment method has been checked');
 			
            var $form = $('form.woocommerce-checkout');
		
			if (   (woo_checkout_fields_array.billing.billing_first_name.required && $('#billing_first_name').val() == "") 
				|| (woo_checkout_fields_array.billing.billing_last_name.required && $('#billing_last_name').val() == "")
                || (woo_checkout_fields_array.billing.billing_last_name.required && $('#billing_last_name').val() == "")
                || (woo_checkout_fields_array.billing.billing_phone.required && $('#billing_phone').val() == "")
                || (woo_checkout_fields_array.billing.billing_email.required && $('#billing_email').val() == "")
                || (woo_checkout_fields_array.order.order_comments.required && $('#order_comments').val() == "")
                || (woo_checkout_fields_array.billing.billing_company.required && $('#billing_company').val() == "")
                || (woo_checkout_fields_array.billing.billing_country.required && $('#billing_country').val() == "")
                || (woo_checkout_fields_array.billing.billing_address_1.required && $('#billing_address_1').val() == "")
                || (woo_checkout_fields_array.billing.billing_address_2.required && $('#billing_address_2').val() == "")
                || (woo_checkout_fields_array.billing.billing_city.required && $('#billing_city').val() == "")
                || (woo_checkout_fields_array.billing.billing_state.required && $('#billing_state').val() == "")
                || (woo_checkout_fields_array.billing.billing_postcode.required && $('#billing_postcode').val() == "")
                || (woo_checkout_fields_array.billing.billing_last_name.required && $('#billing_last_name').val() == "") 
 				|| ($("#terms").length && !($("#terms").is(":checked")))    ){
				//console.log('Validation failed')
				$form.submit();
				return false;
			}

            e.preventDefault();
            window.hpp.payment(params, function (data) {
                if (sha256.validate(params.Key, data.TransactionID, data.MerchantReference, data.Result, data.FailureMessage, data.Amount, data.Checksum)) {
                    $form.append('<input type="hidden" name="TransactionID" value="' + data.TransactionID + '"/>');
                    $form.append('<input type="hidden" name="Amount" value="' + data.Amount + '"/>');
                    $form.append('<input type="hidden" name="MerchantReference" value="' + data.MerchantReference + '"/>');
                    $form.append('<input type="hidden" name="Result" value="' + data.Result + '"/>');
                    $form.append('<input type="hidden" name="FailureMessage" value="' + data.FailureMessage + '"/>');
                    $form.append('<input type="hidden" name="Checksum" value="' + data.Checksum + '"/>');
                    //$form.append( '<input type="hidden" name="OrderID" value="' + order_id + '"/>' );
                    $form.submit();
                    return true;
                } else {
                   // console.log('Invalid checksum');
                    return false;
                }
            }, function (e) {
               // console.log('Failure');
               // console.log(e);
                return false;
            });
            return false;

        } else {
           // console.log('The ecentric payment method has not been checked');
        }

    });
});