jQuery(function ($) {
    $('body').on('click', '#place_order', function (e) {

        if ($('#payment_method_ecentric').is(':checked')) {
            //console.log('The ecentric payment method has been checked');

            e.preventDefault();
            var $form = $('form.woocommerce-checkout');

            window.hpp.payment(params, function (data) {
                if (sha256.validate(params.Key, data.TransactionID, data.MerchantReference, data.Result, data.FailureMessage, data.Amount, data.Checksum)) {
                    $form.append('<input type="hidden" name="TransactionID" value="' + data.TransactionID + '"/>');
                    $form.append('<input type="hidden" name="Amount" value="' + data.Amount + '"/>');
                    $form.append('<input type="hidden" name="MerchantReference" value="' + data.MerchantReference + '"/>');
                    $form.append('<input type="hidden" name="Result" value="' + data.Result + '"/>');
                    $form.append('<input type="hidden" name="FailureMessage" value="' + data.FailureMessage + '"/>');
                    $form.append('<input type="hidden" name="Checksum" value="' + data.Checksum + '"/>');
                    //$form.append( '<input type="hidden" name="OrderID" value="' + order_id + '"/>' );
                    $form.submit();
                    return true;
                } else {
                    //console.log('Invalid checksum');
                    return false;
                }
            }, function (e) {
                //console.log('Failure');
                //console.log(e);
                return false;
            });
            return false;


        } else {
            //console.log('The ecentric payment method has not been checked');
        }

    });
});